from pathlib import Path
from flask import Flask, render_template, request, redirect

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent


# Página de contenidos en ejecución
@app.route('/')
def index():
    return render_template('index.html')


# Habilidades dinámicas
@app.route('/', methods=['POST'])
def process_form():
    button_python = request.form.get('button_python')
    button_discord = request.form.get('button_discord')
    button_html = request.form.get('button_html')
    button_db = request.form.get('button_db')

    return render_template(
        'index.html',
        button_python=button_python,
        button_discord=button_discord,
        button_html=button_html,
        button_db=button_db,
    )


@app.route('/form')
def form():
    return render_template('index.html')


# Resultados del formulario de feedback
@app.route('/submit', methods=['POST'])
def submit_form():
    comment = request.form['text']
    email = request.form['email']

    with open(BASE_DIR / 'form.txt', 'a', encoding='utf-8') as file:
        file.write(
            f'Comentario: {comment}\n'
            f'Email: {email}\n'
            '--------------------\n'
        )

    return render_template(
        'form_result.html',
        comment=comment,
        email=email
    )


if __name__ == '__main__':
    app.run(debug=True)